document.addEventListener('DOMContentLoaded', () => {
    const socialIcons = document.querySelectorAll('.social-icons a');
    
    socialIcons.forEach(icon => {
      icon.addEventListener('mouseover', () => {
        icon.style.boxShadow = '0 0 15px rgba(240, 198, 116, 0.8)';
      });
  
      icon.addEventListener('mouseout', () => {
        icon.style.boxShadow = 'none';
      });
    });
  });